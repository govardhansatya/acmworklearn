# Aerial Airport > v1
https://universe.roboflow.com/gdit/aerial-airport

Provided by a Roboflow user
License: Public Domain

# Overview

The GDIT Aerial Airport dataset consists of aerial images containing instances of parked airplanes. All plane types have been grouped into a single classification named "airplane". 


# Example Image

![Aerial View](https://i.imgur.com/wxqFNd9.png)

